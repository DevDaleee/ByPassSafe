from setuptools import setup, find_packages

setup(
    name='ByPassSafe',
    version='0.2',  # Atualize o número da versão
    packages=find_packages(),
    install_requires=[
        'psycopg2',
        'bcrypt',
    ],
)
